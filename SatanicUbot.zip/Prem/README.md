
```
apt update && apt upgrade -y
```
```
git clone https://github.com/vina0vina/Premium.git
```
```
cd Premium && screen -S Premium
```
```
bash installnode.sh && apt install python3.10-venv
```
```
python3 -m venv Premium && source UbotPrem/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```
